@echo off
REM Genera OrdenadorPinturas.exe (ejecutar en Windows con Python 3 instalado)
py -m pip install --upgrade pip
py -m pip install pyserial matplotlib pyinstaller
py -m PyInstaller --noconfirm --onefile --windowed --name OrdenadorPinturas --hidden-import serial.tools.list_ports_windows ordenador_pinturas.py
echo.
echo Listo: dist\OrdenadorPinturas.exe
pause
